class ImagesController < ApplicationController
end
